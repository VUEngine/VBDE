// This file contains sound and music notes.
//
// Each sound begins with the note length in video frames per note. To
// convert a tempo from beats per minute, use the following formula:
//
//   FramesPerNote = 50 / (BeatsPerMinute / 60)
//
// The result might not be an integer, so round up or down it as appropriate.
// It may not exceed 255 (which is about 11.75 beats per minute) because the
// FramesPerNote field of a tySound structure, where it gets copied to, is
// only 8 bits wide. It must also be larger than 1 (3000 beats per minute).
//
// The last note in the sound is either SUSE_ENDSOUND, which stops the sound, or
// LOOPSOUND, which restarts it from the beginning.

// The following is an assortment of sounds from Soviet Union 2011.

/*u16 sndAmmoPickup[] = {
  5,
  C_3, G_3, E_4, D_3, A_3, F_4, E_3, B_3, G_4,
  SUSE_ENDSOUND,
};*/

u16 sndCannonShot[] = {
  3,
  15,
  G_4, FS4, E_4,
  SUSE_ENDSOUND,  // To demonstrate looping.
};

u16 sndPickupPickup[] = {
  8,
  15,
  C_3, E_3, G_3, HOLD, E_3, G_3, HOLD,
  SUSE_ENDSOUND,
};

u16 sndEnemyDeath[] = {
  2,
  15,
  C_4, D_4, C_4, D_3, E_3, D_3, G_2, F_2, G_2,
  SUSE_ENDSOUND,
};

u16 sndMenuSoundL[] = {
  5,
  7,
  C_3, PAU, PAU, G_3, PAU, PAU, E_4, PAU, PAU, D_3, 
  SUSE_ENDSOUND,
};

u16 sndMenuSoundR[] = {
  5,
  15,
  D_3, PAU, PAU, E_4, PAU, PAU, G_3, PAU, PAU, C_3, 
  SUSE_ENDSOUND,
};

u16 sndGameOver[] = {
  3,
  15,
  G_4, FS4, E_4, G_4, FS4, E_4, G_4, FS4, E_4, C_4, D_4, C_4, D_3, E_3, D_3, G_2, F_2, G_2, 
  SUSE_ENDSOUND,  // To demonstrate looping.
};