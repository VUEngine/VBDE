#include "voices.h"
#include "notes.h"
//#include "../libgccvb/timer.h"
//#include "../libgccvb/interrupts.h"

#define MP_NODE_SHORT_FADE  	0
#define MP_NODE_LONG_INITIAL  	1
#define MP_NODE_LONG_FADE  		2
#define MP_NODE_SFX				3

#define MP_NOT_FREE				100

u8 mp_freeChannelCount = 5;
u8 mp_freeChannels[] = {0,1,2,3,4};

u16 mp_play = 0;
u16 mp_barLength = 100;
u16 mp_qnLength = 25;

const u16 *mp_timing1;
const u16 *mp_timing2;
const u16 *mp_timing3;
const u16 *mp_timing4;
const u16 *mp_timing5;

u8 *mp_volume1;
u8 *mp_volume2;
u8 *mp_volume3;
u8 *mp_volume4;
u8 *mp_volume5;

const u16 *mp_channel1;
const u16 *mp_channel2;
const u16 *mp_channel3;
const u16 *mp_channel4;
const u16 *mp_channel5;

u8 mp_channel1Active=0;
u8 mp_channel2Active=0;
u8 mp_channel3Active=0;
u8 mp_channel4Active=0;
u8 mp_channel5Active=0;

u8 mp_instrument1 = 0;
u8 mp_instrument2 = 0;
u8 mp_instrument3 = 0;
u8 mp_instrument4 = 0;
u8 mp_instrument5 = 0;

s8 mp_replay1=0;
s8 mp_replay2=0;
s8 mp_replay3=0;
s8 mp_replay4=0;
s8 mp_replay5=0;

u16 mp_noteCountC1 = 0;
u16 mp_noteCountC2 = 0;
u16 mp_noteCountC3 = 0;
u16 mp_noteCountC4 = 0;
u16 mp_noteCountC5 = 0;

u16 mp_targetNoteTickC1 = 0;
u16 mp_targetNoteTickC2 = 0;
u16 mp_targetNoteTickC3 = 0;
u16 mp_targetNoteTickC4 = 0;
u16 mp_targetNoteTickC5 = 0;

u16 mp_noteTickC1 = 0;
u16 mp_noteTickC2 = 0;
u16 mp_noteTickC3 = 0;
u16 mp_noteTickC4 = 0;
u16 mp_noteTickC5 = 0;

u16 mp_currNoteC1 = 0;
u16 mp_currNoteC2 = 0;
u16 mp_currNoteC3 = 0;
u16 mp_currNoteC4 = 0;
u16 mp_currNoteC5 = 0;

u8 mp_ChannelStartedC1 = 0;
u8 mp_ChannelStartedC2 = 0;
u8 mp_ChannelStartedC3 = 0;
u8 mp_ChannelStartedC4 = 0;
u8 mp_ChannelStartedC5 = 0;

u8 mp_dynamicSoundC1 = 0;
u8 mp_dynamicSoundC2 = 0;
u8 mp_dynamicSoundC3 = 0;
u8 mp_dynamicSoundC4 = 0;
u8 mp_dynamicSoundC5 = 0;

/*u8 fadeIn1 = 0;
u8 fadeIn2 = 0;
u8 fadeIn3 = 0;
u8 fadeIn4 = 0;
u8 fadeIn5 = 0;

u8 fadeOut1 = 0;
u8 fadeOut2 = 0;
u8 fadeOut3 = 0;
u8 fadeOut4 = 0;
u8 fadeOut5 = 0;*/

void mp_playNote(u8 chan, u16 freq, u8 vol, u8 wav, u8 mode) {
    
	if(freq==PAU)
	{
		SND_REGS[chan].SxINT = 0; 
		return;
	}
	
	if(mode==MP_NODE_SHORT_FADE)
	{
		SND_REGS[chan].SxINT = 0;
		SND_REGS[chan].SxRAM = wav;
		SND_REGS[chan].SxEV0 = 0xF1;
		//SND_REGS[chan].SxEV1 = 0x08; 	// do this on emultor (register seem to have wrong order)
		SND_REGS[chan].SxEV1 = 0x01; 	// this is correct for hardware
		SND_REGS[chan].SxFQH = freq >> 8;
		SND_REGS[chan].SxFQL = freq & 0xFF;
		SND_REGS[chan].SxLRV = (vol << 4) | vol;
		SND_REGS[chan].SxINT = 0x80;
	}
	else if(mode==MP_NODE_LONG_INITIAL)
	{
		SND_REGS[chan].SxRAM = wav;
		SND_REGS[chan].SxEV1 = 0x00;
		SND_REGS[chan].SxEV0 = 0xF0;
		SND_REGS[chan].SxFQH = freq >> 8;
		SND_REGS[chan].SxFQL = freq & 0xFF;
		SND_REGS[chan].SxLRV = (vol << 4) | vol;
		SND_REGS[chan].SxINT = 0x80;
	}
	else if(mode==MP_NODE_LONG_FADE)
	{
		SND_REGS[chan].SxEV0 = 0xF1;
		SND_REGS[chan].SxEV1 = 0x01; 	// this is correct for hardware
	}
	else if(mode==MP_NODE_SFX)
	{
		SND_REGS[chan].SxINT = 0x9F;         // I don't know what this is for.
        SND_REGS[chan].SxRAM = wav;
		SND_REGS[chan].SxFQH = freq >> 8;    // Frequency; higher 3 bits.
        SND_REGS[chan].SxFQL = freq & 0xFF;  // Frequency; lower 8 bits.
        SND_REGS[chan].SxLRV = (vol << 4) | vol; // Left/right speaker volume.
        SND_REGS[chan].SxEV0 = 0xFC;         	// No fadeout; volume is constant.
        SND_REGS[chan].SxEV1 = 0x02;         	// Repeat it forever.
	}
	
}

//SU Sound Engine Code

const u8 kModData[] = {
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 16, 17, 18, 19, 20, 21, -1, -2, -3, -4, -5,
  -6, -7, -8, -9, -16, -17, -18, -19, -20, -21, -22
};

// Special sound notes
#define SUSE_ENDSOUND  0xFFFF  // Ends the sound.
#define SUSE_LOOPSOUND 0xFFFE  // Repeats the sound from the beginning.

// Maximum number of sounds
#define suse_kMaxSounds 5  // No point in changing this (and 4 is the max).

// Sound property structure
typedef struct
{
  u16* StartPtr;           // Start of data (nonzero if the sound is playing)
  unsigned int NoteIndex;  // Index of current note, begins at 1
  u8 FramesPerNote;        // How many video frames each note lasts.
  u8 FramesLeft;           // How many video frames until next note.
  u16 Volume;
} suse_tySound;

// Sound array
suse_tySound Sound[suse_kMaxSounds];
