#include "midiPlayer.h"
#include "su11sfx.c"


//#define MP_NODE_FADE_OFFSET     25
//#define MP_NODE_FADE_OFFSET     384


void mp_setBarLength(u16 barLength)
{
	mp_barLength = barLength;
	mp_qnLength = ( barLength / 4 );
}

//sets how many notes should be played on each channel
void mp_setNoteCount(u16 noteCountC1, u16 noteCountC2, u16 noteCountC3, u16 noteCountC4, u16 noteCountC5)
{
	mp_noteCountC1 = noteCountC1;
	mp_noteCountC2 = noteCountC2;
	mp_noteCountC3 = noteCountC3;
	mp_noteCountC4 = noteCountC4;
	mp_noteCountC5 = noteCountC5;
}

//sets the replay
void mp_setReplay(s8 replay1, s8 replay2, s8 replay3, s8 replay4, s8 replay5)
{
	mp_replay1=replay1;
	mp_replay2=replay2;
	mp_replay3=replay3;
	mp_replay4=replay4;
	mp_replay5=replay5;
}

//sets the timing
void mp_setTiming(const u16 *timingC1, const u16 *timingC2, const u16 *timingC3, const u16 *timingC4, const u16 *timingC5)
{
	mp_timing1=timingC1;
	mp_timing2=timingC2;
	mp_timing3=timingC3;
	mp_timing4=timingC4;
	mp_timing5=timingC5;
}

//sets the volume
void mp_setVolume(u8 *volumeC1, u8 *volumeC2, u8 *volumeC3, u8 *volumeC4, u8 *volumeC5)
{
	mp_volume1=volumeC1;
	mp_volume2=volumeC2;
	mp_volume3=volumeC3;
	mp_volume4=volumeC4;
	mp_volume5=volumeC5;
}

//sets the music for the channels
void mp_setChannels(const u16 *channel1I, const u16 *channel2I, const u16 *channel3I, const u16 *channel4I, const u16 *channel5I)
{
	mp_channel1 = channel1I;
	mp_channel2 = channel2I;
	mp_channel3 = channel3I;
	mp_channel4 = channel4I;
	mp_channel5 = channel5I;
}

void mp_setFreeChannels()
{
	mp_freeChannels[0] = MP_NOT_FREE; // this channel is reserved for sfx
	mp_freeChannels[1] = MP_NOT_FREE;
	mp_freeChannels[2] = MP_NOT_FREE;
	mp_freeChannels[3] = MP_NOT_FREE;
	mp_freeChannels[4] = MP_NOT_FREE;
	//mp_freeChannels[5] = MP_NOT_FREE;
	
	mp_freeChannelCount = 0;
	if(!mp_channel1Active)
	{
		mp_freeChannels[mp_freeChannelCount] = 0;
		mp_freeChannelCount++;
	}
	
	if(!mp_channel2Active)
	{
		mp_freeChannels[mp_freeChannelCount] = 1;
		mp_freeChannelCount++;
	}
	
	if(!mp_channel3Active)
	{
		mp_freeChannels[mp_freeChannelCount] = 2;
		mp_freeChannelCount++;
	}
	
	if(!mp_channel4Active)
	{
		mp_freeChannels[mp_freeChannelCount] = 3;
		mp_freeChannelCount++;
	}
	
	if(!mp_channel5Active)
	{
		mp_freeChannels[mp_freeChannelCount] = 4;
		mp_freeChannelCount++;
	}
}

//sets the active channels
void mp_setActiveChannels(u8 channel1AI, u8 channel2AI, u8 channel3AI, u8 channel4AI, u8 channel5AI)
{
	mp_channel1Active = channel1AI;
	mp_channel2Active = channel2AI;
	mp_channel3Active = channel3AI;
	mp_channel4Active = channel4AI;
	mp_channel5Active = channel5AI;
	
	mp_setFreeChannels();
}

//sets instruments for channels
void mp_setInsturments(u8 instumentC1, u8 instumentC2, u8 instumentC3, u8 instumentC4, u8 instumentC5)
{
	mp_instrument1 = instumentC1;
	mp_instrument2 = instumentC2;
	mp_instrument3 = instumentC3;
	mp_instrument4 = instumentC4;
	mp_instrument5 = instumentC5;
}

void mp_setDynamicSound(u8 dynamicSoundC1, u8 dynamicSoundC2, u8 dynamicSoundC3, u8 dynamicSoundC4, u8 dynamicSoundC5)
{
	mp_dynamicSoundC1 = dynamicSoundC1;
	mp_dynamicSoundC2 = dynamicSoundC2;
	mp_dynamicSoundC3 = dynamicSoundC3;
	mp_dynamicSoundC4 = dynamicSoundC4;
	mp_dynamicSoundC5 = dynamicSoundC5;
}

//loads a song from the library
/*void mp_loadSong(u16 index)
{
	mp_setChannels(ml_music_c1[index], ml_music_c2[index], ml_music_c3[index], ml_music_c4[index], ml_music_c5[index]);
	mp_setActiveChannels(ml_music_ca1[index], ml_music_ca2[index], ml_music_ca3[index], ml_music_ca4[index], ml_music_ca5[index]);
	mp_setNoteCount(ml_music_nc1[index], ml_music_nc2[index], ml_music_nc3[index], ml_music_nc4[index], ml_music_nc5[index]);
	
	mp_setTiming(ml_music_t1[index], ml_music_t2[index], ml_music_t3[index], ml_music_t4[index], ml_music_t5[index]);
	mp_setVolume(ml_music_v1[index], ml_music_v2[index], ml_music_v3[index], ml_music_v4[index], ml_music_v5[index]);
	mp_setReplay(ml_music_r1[index], ml_music_r2[index], ml_music_r3[index], ml_music_r4[index], ml_music_r5[index]);
	mp_setInsturments(ml_music_in1[index], ml_music_in2[index], ml_music_in3[index], ml_music_in4[index], ml_music_in5[index]);
	mp_setBarLength(ml_music_bl[index]);
}*/

//plays a single note (thy to DanB)
/*void mp_playNoteAlt(u8 chan, u16 freq, u8 vol, u8 wav) {
    
	if(freq==PAU)
	{
		SND_REGS[chan].SxINT = 0; 
		return;
	}
	
	SND_REGS[chan].SxRAM = wav;
	
	SND_REGS[chan].SxEV0 = 0xF0;
	SND_REGS[chan].SxEV1 = 0x00;
	
	//Set up the frequency the channel will play
    SND_REGS[chan].SxFQH = freq >> 8;
    SND_REGS[chan].SxFQL = freq & 0xFF;

    //Set the volume for the channel (0-15, same for left/right)
    SND_REGS[chan].SxLRV = (vol << 4) | vol;

	SND_REGS[chan].SxINT = 0x80;
}

void mp_fadeIn(u8 chan, u8 *fadeIn, u8 vol)
{
	if(*fadeIn < vol)
	{
		*fadeIn = *fadeIn + 1;
		SND_REGS[chan].SxLRV = (*fadeIn << 4) | *fadeIn;
	}
	
}

void mp_fadeOut(u8 chan, u8 *fadeOut)
{
	if(*fadeOut > 0)
	{
		*fadeOut = *fadeOut - 1;
		SND_REGS[chan].SxLRV = (*fadeOut << 4) | *fadeOut;
	}
	
}*/

/*u16 mp_playChannelAlt(u8 channel, u8 *channelStarted, u16 *noteCount, u16 *noteTick, u16 *targetNoteTick, u16 *currentNote, u16 *notes, u16 *timing, s8 *replay, u8 instrument, u8 *volume)
{
	if((*channelStarted==0) || (*noteTick >= *targetNoteTick)) // it is time to play a new note
	{
		if(*channelStarted==1)
		{
			*currentNote = *currentNote + 1;
		}
		
		*noteTick = 0;
		*channelStarted = 1;
		
		if (*currentNote >= *noteCount) //we are done playing this song
		{
			mp_playNoteAlt(channel, PAU, 0, 0);
			
			//start replay if neccessary
			if(*replay==0)
			{
				mp_playerStop();
			}
			else if(*replay > 0)
			{
				*currentNote=0;
				*noteTick=0;
				*replay = *replay - 1;
			}
			else if(*replay < 0)
			{
				*currentNote=0;
				*noteTick=0;
			}
			
			return *currentNote;
		}
		else { //we have to play a new note
			
			fadeOut1 = 0;
			fadeIn1  = 0;
			
			*targetNoteTick = timing[*currentNote];
			//mp_playNote(channel, notes[*currentNote], volume[*currentNote], instrument, MP_NODE_LONG_INITIAL);
			if(*targetNoteTick > (volume[*currentNote]*2))
			{
				mp_playNoteAlt(channel, notes[*currentNote], 0, instrument);
			}
			else
			{
				mp_playNoteAlt(channel, notes[*currentNote], volume[*currentNote], instrument);
			}
		}
	} 
	else if(*noteTick < *targetNoteTick)
	{
		if(*targetNoteTick > (volume[*currentNote]*2)) // fade in an out
		{
			if(*noteTick < volume[*currentNote])
			{
				mp_fadeIn(channel, &fadeIn1, volume[*currentNote]);
				*noteTick = *noteTick + 1;
				return 1;
			}
			else if((*noteTick+volume[*currentNote]) > *targetNoteTick)
			{
				mp_fadeOut(channel, &fadeOut1);
				*noteTick = *noteTick + 1;
				return 2;
			}
		}
		else if(*targetNoteTick > (volume[*currentNote])) // fade out
		{
			if((*noteTick+volume[*currentNote]) > *targetNoteTick)
			{
				mp_fadeOut(channel, &fadeOut1);
				*noteTick = *noteTick + 1;
				return 3;
			}
		}
		
		*noteTick = *noteTick + 1;
		return 4;
	}
	
	*noteTick = *noteTick + 1;
	
	return 7;
}*/

void mp_playerStop()
{
	mp_play=0;
	
	timer_enable(0);
	timer_clearstat();
	
	/*mp_noteTickC1 = 0;
	mp_noteTickC2 = 0;
	mp_noteTickC3 = 0;
	mp_noteTickC4 = 0;
	mp_noteTickC5 = 0;

	mp_currNoteC1 = 0;
	mp_currNoteC2 = 0;
	mp_currNoteC3 = 0;
	mp_currNoteC4 = 0;
	mp_currNoteC5 = 0;

	mp_ChannelStartedC1 = 0;
	mp_ChannelStartedC2 = 0;
	mp_ChannelStartedC3 = 0;
	mp_ChannelStartedC4 = 0;
	mp_ChannelStartedC5 = 0;*/
	
	suse_stopAllSounds();
	
	mp_channel1Active = 0;
	mp_channel2Active = 0;
	mp_channel3Active = 0;
	mp_channel4Active = 0;
	mp_channel5Active = 0;
	
	
	mp_playNote(0, PAU, 0, 0, 0);
	mp_playNote(1, PAU, 0, 0, 0);
	mp_playNote(2, PAU, 0, 0, 0);
	mp_playNote(3, PAU, 0, 0, 0);
	mp_playNote(4, PAU, 0, 0, 0);
	
	mp_setFreeChannels();
	
	
	
}

u16 mp_playChannel(u8 channel, u8 *channelStarted, u16 *noteCount, u16 *noteTick, u16 *targetNoteTick, u16 *currentNote, const u16 *notes, const u16 *timing, s8 *replay, u8 instrument, u8 *volume, u8 dynamicSound)
{
	u16 vol = 0;
	
	if(dynamicSound==1)
	{
		vol = volume[*currentNote];
	}
	else
	{
		vol = volume[0];
	}
	
	if((*channelStarted==0) || (*noteTick >= *targetNoteTick)) // it is time to play a new note
	{
		if(*channelStarted==1)
		{
			*currentNote = *currentNote + 1;
		}
		
		*noteTick = 0;
		*channelStarted = 1;
		
		if (*currentNote >= *noteCount) //we are done playing this song
		{
			mp_playNote(channel, PAU, 0, 0, 0);
			
			//start replay if neccessary
			if(*replay==0)
			{
				mp_play=0;
				*currentNote=0;
				*noteTick=0;
				*channelStarted=0;
				mp_playerStop();
			}
			else if(*replay > 0)
			{
				*currentNote=0;
				*noteTick=0;
				*channelStarted=0;
				*replay = *replay - 1;
			}
			else if(*replay < 0)
			{
				*currentNote=0;
				*channelStarted=0;
				*noteTick=0;
			}
			
			return *currentNote;
		}
		else { //we have to play a new note
			
			*targetNoteTick = timing[*currentNote];
			
			//play long nodes without fade first
			if(*targetNoteTick > mp_qnLength)
			{
				mp_playNote(channel, notes[*currentNote], vol, instrument, MP_NODE_LONG_INITIAL);
			}
			else
			{
				mp_playNote(channel, notes[*currentNote], vol, instrument, MP_NODE_SHORT_FADE);
			}
		}
	}
	else if((*noteTick + mp_qnLength) == *targetNoteTick ) // the last tick of a note fades, makes the song more smoth (or maybe changes nothing)
	{
		if(notes[*currentNote]!=PAU)
		{
			mp_playNote(channel, notes[*currentNote], vol, instrument, MP_NODE_LONG_FADE);
		}
	}
		
	*noteTick = *noteTick + 1;
	
	return *currentNote;
}

//this function should be called in every frame to play music
u16 mp_playMusic() {

	if(mp_play==1)
	{
		if(mp_channel1Active==1) 
		{
			mp_playChannel(0, &mp_ChannelStartedC1, &mp_noteCountC1, &mp_noteTickC1, &mp_targetNoteTickC1, &mp_currNoteC1, mp_channel1, mp_timing1, &mp_replay1, mp_instrument1, mp_volume1, mp_dynamicSoundC1);
		}
		
		if(mp_channel2Active==1) 
		{
			mp_playChannel(1, &mp_ChannelStartedC2, &mp_noteCountC2, &mp_noteTickC2, &mp_targetNoteTickC2, &mp_currNoteC2, mp_channel2, mp_timing2, &mp_replay2, mp_instrument2, mp_volume2, mp_dynamicSoundC2);
		}
		
		if(mp_channel3Active==1) 
		{
			mp_playChannel(2, &mp_ChannelStartedC3, &mp_noteCountC3, &mp_noteTickC3, &mp_targetNoteTickC3, &mp_currNoteC3, mp_channel3, mp_timing3, &mp_replay3, mp_instrument3, mp_volume3, mp_dynamicSoundC3);
		}
		
		if(mp_channel4Active==1) 
		{
			mp_playChannel(3, &mp_ChannelStartedC4, &mp_noteCountC4, &mp_noteTickC4, &mp_targetNoteTickC4, &mp_currNoteC4, mp_channel4, mp_timing4, &mp_replay4, mp_instrument4, mp_volume4, mp_dynamicSoundC4);
		}
		
		if(mp_channel5Active==1) 
		{
			mp_playChannel(4, &mp_ChannelStartedC5, &mp_noteCountC5, &mp_noteTickC5, &mp_targetNoteTickC5, &mp_currNoteC5, mp_channel5, mp_timing5, &mp_replay5, mp_instrument5, mp_volume5, mp_dynamicSoundC5);
		}
	}
	return 0;

}

void timer_hnd() {
	VIP_REGS[INTCLR] = VIP_REGS[INTPND];
	timer_enable(0);
	timer_clearstat();
	timer_enable(1);
	mp_playMusic();
}

void activateTimer()
{
	//timer_enable(0);
	tim_vector = (u32)(timer_hnd);
	VIP_REGS[INTCLR] = VIP_REGS[INTPND];
	VIP_REGS[INTENB] = 0x0000;				//This is only for enabling\disabling different kinds of VPU and error ints
	set_intlevel(0);
	
	timer_freq(TIMER_20US);
	timer_set(TIME_US(mp_barLength));
	timer_clearstat();
	timer_int(1);
	timer_enable(1);
}

//starts the music player
void mp_playerStart()
{
	mp_noteTickC1 = 0;
	mp_noteTickC2 = 0;
	mp_noteTickC3 = 0;
	mp_noteTickC4 = 0;
	mp_noteTickC5 = 0;

	mp_currNoteC1 = 0;
	mp_currNoteC2 = 0;
	mp_currNoteC3 = 0;
	mp_currNoteC4 = 0;
	mp_currNoteC5 = 0;

	mp_ChannelStartedC1 = 0;
	mp_ChannelStartedC2 = 0;
	mp_ChannelStartedC3 = 0;
	mp_ChannelStartedC4 = 0;
	mp_ChannelStartedC5 = 0;
	
	suse_stopAllSounds();
	mp_setFreeChannels();
	
	mp_play=1;
	activateTimer();
}


void mp_init()
{
	u16 i = 0;
	
	for(i = 0; i <= 0x7C; i++) 
	{	
		MODDATA[i << 2] = kModData[i];
	}
	
	copymem((void*)WAVEDATA1, (void*)PIANO, 	32);
	copymem((void*)WAVEDATA2, (void*)TRIANGLE,  32);
	copymem((void*)WAVEDATA3, (void*)TRUMPET,  	32);
	copymem((void*)WAVEDATA4, (void*)VIOLIN, 	32);
	copymem((void*)WAVEDATA5, (void*)SINE,  	32);
	
}