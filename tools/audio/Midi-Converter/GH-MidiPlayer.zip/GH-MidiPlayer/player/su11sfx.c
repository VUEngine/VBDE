void suse_playSound (const u16* DataPtr)
{
  // Sets up a sound to play. If there are too many sounds playing, the sound
  // will not play.

  u8 i;  // Loop counter for finding a free sound.
  u8 channel;

  for(i = 0; i < mp_freeChannelCount; i++)
  {
	if(i<suse_kMaxSounds)
	{
		if(mp_freeChannels[i] != MP_NOT_FREE)
		{
			channel = mp_freeChannels[i];
			if(!Sound[channel].StartPtr)
			{
			  Sound[channel].StartPtr = (u16*)(DataPtr + 2);
			  Sound[channel].Volume = (u16)*(DataPtr + 1);
			  Sound[channel].NoteIndex = -1;
			  Sound[channel].FramesPerNote = Sound[channel].FramesLeft = *DataPtr;

			  break;
			}
		}
	}
  }
  
  /*for(i = 0; i < suse_kMaxSounds; i++)
  {
    if(!Sound[i].StartPtr)
    {
      Sound[i].StartPtr = (u16*)(DataPtr + 2);
	  Sound[i].Volume = (u16)*(DataPtr + 1);
      Sound[i].NoteIndex = -1;
      Sound[i].FramesPerNote = Sound[i].FramesLeft = *DataPtr;

      break;
    }
  }*/
}

void suse_stopSound (unsigned char SoundIndex)
{
  // Stops a sound.

  // Mark it as nonexistant.
  Sound[SoundIndex].StartPtr = 0;
  
  // Make it silent.
  //SND_REGS[SoundIndex].SxLRV = 0;
  SND_REGS[SoundIndex].SxINT = 0; 
}

void suse_stopAllSounds ()
{
  // Stops all sounds.

	u8 i;  // Loop counter.
	for(i = 0; i < mp_freeChannelCount; i++)
	{
		if(i<suse_kMaxSounds)
		{
			if(mp_freeChannels[i] != MP_NOT_FREE)
			{
				//channel = mp_freeChannels[i];
				suse_stopSound(mp_freeChannels[i]);
			}
		}
	}
  //for(i = 0; i < suse_kMaxSounds; i++) suse_stopSound(i);
}

u16 suse_doSounds ()
{
  // Changes notes on sounds if necessary or ends them.

  u8 i;      // Loop counter.
  unsigned short Note;  // Temporary variable for holding the next note.

  for(i = 0; i < suse_kMaxSounds; i++)
  {
    if(Sound[i].StartPtr)
    {
      if(!(--Sound[i].FramesLeft))
      {
        Sound[i].NoteIndex++;                          // Move to next note.
        Note = Sound[i].StartPtr[Sound[i].NoteIndex];  // Get it.
		

        // Set length of new note.
        Sound[i].FramesLeft = Sound[i].FramesPerNote;

        // Is it a special note?
        switch(Note)
        {
          case HOLD:
            // Continue playing the previous note.
            continue;

          case SUSE_ENDSOUND:
            // End the sound.
            suse_stopSound(i);
            continue;

          case SUSE_LOOPSOUND:
            // Restart the sound.
            Sound[i].NoteIndex = -1;  // Will get incremented next time.
            Sound[i].FramesLeft = 1;  // Will get decremented next time.
            continue;
        }

		mp_playNote(i, Note, (u8)Sound[i].Volume, 0, MP_NODE_SFX);
        // Send the note to the sound channel.
        
		//return(Note);
      }
    }
  }
  
  return 1;
}

