// Game Hero Midi Player

#include "./libgccvb/libgccvb.h"

#include "fonts/fontChar.h"
#include "imgs/logoChar.h"
#include "imgs/logoMap.h"

#include "player/midiPlayer.c"
#include "music/the_legend_of_zelda.h"

#include "sfx/sounddat.h" 
 
int main()
{
	u8 press = 0;
	u8 start=1;
	int currNoteDebug = 0;
	int lastNoteDebug = -1;
	HWORD pad;
	
	vbDisplayOn();
	copymem((void*)CharSeg0, (void*)LOGOCHAR, 8192); 
	copymem((void*)BGMap(0), (void*)LOGOMAP, 8192);
	copymem ((void*)CharSeg3, (void*)FONT, 512*16);
	
	//init MidiPlayer
	mp_init();
	
	while(1)
	{
		//setting up all images
		if(start==1)
		{
			WORLD_HEAD(31,WRLD_ON | WRLD_BGMAP | 0);
			WORLD_GSET(31,0,0,0);
			WORLD_SIZE(31,384,224);
			
			WORLD_HEAD(30,WRLD_ON | WRLD_BGMAP | 1);
			WORLD_GSET(30,0,0,0);
			WORLD_SIZE(30,384,224);
			
			WORLD_HEAD(29, WRLD_END);
			start=0;
			vbDisplayShow();
			
			mp_playerStop();
			mp_loadSong_the_legend_of_zelda();
			mp_playerStart();
		}
		
		vbTextOutS(1, 1, 1, itoa(mp_freeChannelCount, 10, 3));
		
		if(press == 0 && (pad&K_ANY)) 
		{
			suse_playSound(sndMenuSoundL);
			press =1;
		}
		if(press==1 && !(pad&K_ANY))
		{
			suse_playSound(sndMenuSoundR);
			press =0;
		}
		
		currNoteDebug = suse_doSounds();
		
		pad = vbReadPad(); 	//get buttons
		vbWaitFrame(0);		//wait 
	}
    
    return 0;
}
