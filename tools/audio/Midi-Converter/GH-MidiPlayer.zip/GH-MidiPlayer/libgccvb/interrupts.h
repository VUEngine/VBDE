#ifndef _INTERRUPTS_H_
#define _INTERRUPTS_H_

#include "types.h"

extern u32 key_vector;
extern u32 tim_vector;
extern u32 cro_vector;
extern u32 com_vector;
extern u32 vpu_vector;


#endif //_INTERRUPTS_H_
